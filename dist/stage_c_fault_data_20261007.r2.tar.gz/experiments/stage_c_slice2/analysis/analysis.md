## Stage C 主分析

- 验证模型作用域检查: 通过

> ⛔ **正式显著性推断已被拒绝**（矩阵不健康）：
> - 672 个期望格子没有产物
> - 672 组控制/故障臂未配平
> 以下数值仅为描述性，p 值已置空。
- 主模型: deepseek_v41_flash, qwen38_flash
- 主观测数: 96，配对数: 48

| 故障 | 配对 | Δ(pp) | 95% CI | p | p(Holm) |
|---|---|---|---|---|---|
| agent_param_error | 16 | +6.2 | [-12.5, +25.0] | — | — |
| web_dom_missing | 16 | -6.2 | [-18.8, +0.0] | — | — |
| web_http_error | 16 | -6.2 | [-18.8, +12.5] | — | — |

步数耗尽（描述性，不计入成功率）：总体 22/96 = 22.9%，未知 0/96，均值步数 9.8
  - 故障 `agent_param_error`: 7/32 = 22%（未知 0）
  - 故障 `web_dom_missing`: 9/32 = 28%（未知 0）
  - 故障 `web_http_error`: 6/32 = 19%（未知 0）

Holm 家族：per_fault_primary = ['agent_param_error', 'web_dom_missing', 'web_http_error']

逐 (model, architecture, fault) 描述性结果：

| model | arch | fault | n_pair | control | fault | Δ(pp) | 95% CI | p |
|---|---|---|---|---|---|---|---|---|
| deepseek_v41_flash | plan_execute | agent_param_error | 16 | 0.312 | 0.250 | +6.2 | [-12.5, +25.0] | — |
| deepseek_v41_flash | plan_execute | web_dom_missing | 16 | 0.188 | 0.250 | -6.2 | [-18.8, +0.0] | — |
| deepseek_v41_flash | plan_execute | web_http_error | 16 | 0.188 | 0.250 | -6.2 | [-18.8, +12.5] | — |

- 交互检验: 无法估计（interaction requires exactly two models and two architectures）

> 退化量定义为 control 成功率减 fault 成功率（百分点 = ×100）。
> 区间按任务整群、按四个预注册类别分层自助；重复 trial 不是独立样本。
> Holm 家族固定为三个故障级主对比；逐 (model, architecture, fault) 格子为描述性。
> 矩阵不健康（缺格/未配对/评分报错）时不输出 p 值，只给描述性区间；不显著只能报告为功效不足，不能当作等价性证据。
> V4 Pro 仅用于共同 8 任务次级分析，不进入主估计，也不报显著性。
